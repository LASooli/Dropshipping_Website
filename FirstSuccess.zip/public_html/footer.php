<p>
<a href="contact.php">Contact</a></p>

</body>
</html>
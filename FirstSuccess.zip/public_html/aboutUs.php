
<?php $scriptList = array('js/jquery3.3.js', 'js/ShowHide.js', 'js/Cart.js', 'js/Reviews.js');
    include("header.php"); include("addReviewForm.php"); ?>




        <main>
            <h2>About Us</h2>

           <p>We are an environmental conservation organisation. There will be more to come. Watch this space.
           If you would like to get in contact, please send a message on facebook until we get a proper messaging service available on our website.
           Thanks.</p>

        </main>

        <footer>
            <?php include("footer.php"); ?>
        </footer>

    </body>
</html>
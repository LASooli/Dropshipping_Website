var headerMenu = (function () {
    var pub = {};

    pub.setup = function() {
        document.getElementById('logo').click(function(){})
    }

    return pub;
}());

$(document).ready(headerMenu.setup);
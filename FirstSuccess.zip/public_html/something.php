
<?php $scriptList = array('js/jquery3.3.js', 'js/ShowHide.js', 'js/Cart.js', 'js/Reviews.js');
include('header.php'); include('addReviewForm.php'); ?>



        <main>
        </main>

        <footer>
            <?php include("footer.php"); ?>
        </footer>

    </body>
</html>
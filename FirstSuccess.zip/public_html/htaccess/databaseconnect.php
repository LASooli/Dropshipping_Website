<?php
$servername = "127.0.0.1:3306";
$database = "u922724281_EnvFrn";
$username = "u922724281_main";
$password = "@Bron5a1";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    die("Connection Failed");
    //die("Connection failed: " . mysqli_connect_error());
}
//echo "Connected successfully";





?>


<?php $scriptList = array('js/jquery3.3.js', 'carousel.js');
     include("header.php"); ?>



        <main>
            <body>
            <h3>
                Welcome to EnvironmentFriend
            </h3><br>

            <h3>A startup joining the mission of saving the environment</h3> <br>
            <br>
            <br>
            <h3>This website is currently in production. Please come back soon when it is complete.</h3>
            </body>

            <div id="carousel"></div>
        </main>

        <footer>
            <?php include("footer.php"); ?>
        </footer>

    </body>
</html>
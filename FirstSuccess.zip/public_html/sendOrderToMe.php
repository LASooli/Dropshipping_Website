hello
<?php
/**
$to = "rawirinathan@gmail.com";

$msg = "hello";

$subject = "Email Subject";

$message = 'Dear Nathan <br>';
$message .= "Some email <br><br>";
$message .= "Regards,<br>";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <rawirinathan1@gmail.com>' . "\r\n";
$headers .= 'Cc: myboss@example.com' . "\r\n";

$from = 'From: <admin@environmentfriend.site>';

mail($to, $subject, $msg, $from);
 *
 * */

?>

<?php
// the message
$msg = "First line of text\nSecond line of text";

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);

// send email
mail("rawirinathan@gmail.com","Email From EnvFriend",$msg);
?>

mail
